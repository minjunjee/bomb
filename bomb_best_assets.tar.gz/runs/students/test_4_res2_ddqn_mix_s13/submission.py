# 🔒 KEEP the line above: it saves this cell as submission.py.
# Everything grading needs must be in this cell. The server has: numpy, torch (CPU), bombcompetition.
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from bombcompetition import DELTAS, MOVES, RULES, Action, blast_cells, legal_actions  # the engine API (section 3)
from bombcompetition.neural import CHANNELS, IN_CHANNELS  # the fixed input: (IN_CHANNELS, 9, 9), see section 3


# ============================================================================================
# ✏️ EDIT: your helper code for Net (optional). Everything Net uses must be in this cell,
# because the server only gets this file.
# ============================================================================================


# ============================================================================================
# ✏️ EDIT: the network. Any layers; Net() without arguments; output: 6 action scores.
# With Q-learning they are Q(s, a); the server plays the action with the highest score.
# ============================================================================================
class Block(nn.Module):
    """conv - relu - conv, plus the input (a residual block)"""

    def __init__(self, c):
        super().__init__()
        self.a = nn.Conv2d(c, c, kernel_size=3, padding=1)
        self.b = nn.Conv2d(c, c, kernel_size=3, padding=1)

    def forward(self, x):
        y = F.relu(self.a(x))
        y = self.b(y)
        return F.relu(x + y)


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv_in = nn.Conv2d(IN_CHANNELS, 48, kernel_size=3, padding=1)
        self.res1 = Block(48)
        self.res2 = Block(48)
        self.fc1 = nn.Linear(48 * 9 * 9, 256)
        self.fc2 = nn.Linear(256, 6)

    def forward(self, x):
        x = F.relu(self.conv_in(x))
        x = self.res2(self.res1(x))
        x = F.relu(self.fc1(x.flatten(1)))
        return self.fc2(x)


# ============================================================================================
# 🔒 How it plays (fixed, on the server; you do not write it):
#     net = Net(); net.load_state_dict(torch.load("submission.pth"))
#     action = NeuralPolicy(net).act(obs)    # turn -> the fixed preprocess -> Net -> highest score
# ============================================================================================
