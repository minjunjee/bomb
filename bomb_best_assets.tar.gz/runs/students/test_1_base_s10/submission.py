# 🔒 KEEP the line above: it saves this cell as submission.py.
# Everything grading needs must be in this cell. The server has: numpy, torch (CPU), bombcompetition.
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from bombcompetition import DELTAS, MOVES, RULES, Action, blast_cells, legal_actions  # the engine API (section 3)
from bombcompetition.neural import CHANNELS, IN_CHANNELS  # the fixed input: (IN_CHANNELS, 9, 9), see section 3


# ============================================================================================
# ✏️ EDIT: your helper code for Net (optional). Everything Net uses must be in this cell,
# because the server only gets this file.
# ============================================================================================


# ============================================================================================
# ✏️ EDIT: the network. Any layers; Net() without arguments; output: 6 action scores.
# With Q-learning they are Q(s, a); the server plays the action with the highest score.
# ============================================================================================
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Conv2d(IN_CHANNELS, 32, 3, padding=1), nn.ReLU(),
            nn.Conv2d(32, 32, 3, padding=1), nn.ReLU(),
            nn.Flatten(), nn.Linear(32 * 9 * 9, 128), nn.ReLU(),
            nn.Linear(128, 6),
        )

    def forward(self, x):
        return self.layers(x)


# ============================================================================================
# 🔒 How it plays (fixed, on the server; you do not write it):
#     net = Net(); net.load_state_dict(torch.load("submission.pth"))
#     action = NeuralPolicy(net).act(obs)    # turn -> the fixed preprocess -> Net -> highest score
# ============================================================================================
